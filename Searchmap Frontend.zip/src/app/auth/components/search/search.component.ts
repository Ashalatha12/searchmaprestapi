import { Component, OnInit } from '@angular/core';
import { AlertService } from 'src/app/core/services/alert.service';
import { MapService } from '../../services/map.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
})
export class SearchComponent {
  searchQuery = '';
  addresses = [];
  selectedAddress: any;
  message = '';
  myaddress = [];

  constructor(
    private mapService: MapService,
    private alertService: AlertService
  ) {}
  onChange() {
    if (this.searchQuery.trim() && this.searchQuery.length > 3) {
      const address = this.searchQuery;
      this.mapService.getAddress(address).subscribe((res: any) => {
        console.log({ res });

        if (res) {
          this.addresses = res.copResults;
        }
      });
    }
    if (!this.searchQuery) {
      this.addresses = [];
    }
  }
  selectAddress(address: any) {
    console.log('you selected address', address);
    this.selectedAddress = address;
    this.searchQuery = address.formattedAddress;
    this.addresses = [];
  }
  saveAddress() {
    console.log(this.selectedAddress);
    this.mapService.saveAddressToDatabase(this.selectedAddress).subscribe(
      (res) => {
        console.log({ res });
        console.log('Saved..');
        this.searchQuery = '';
        this.message = 'Saved Successfully';
        this.myaddress.push(this.selectedAddress);
        this.selectedAddress = {};
        this.alertService.setAlert({
          alertType: 'success',
          message: 'Saved successfully',
        });
      },
      (err) => {}
    );
  }
}
