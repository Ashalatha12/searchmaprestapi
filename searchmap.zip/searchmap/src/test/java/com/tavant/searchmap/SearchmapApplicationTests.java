package com.tavant.searchmap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchmapApplicationTests {

	@Test
	void contextLoads() {
	}

}
